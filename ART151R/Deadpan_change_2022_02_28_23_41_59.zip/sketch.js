function setup() {
  createCanvas(500, 500);
  
  
}

function draw() {
  background(500);
  
  
  
  fill(300, 300, 200)
  

  
  
  
  arc(250, 400, 300, 150, 150, PI + QUARTER_PI, CHORD);
  
  ellipse(230, 300, 100, 300);
  ellipse(260, 300, 100, 300);
  
  
  fill(0)
  ellipse(250, 400, 130, 120);
  
}
